package br.com.cardoso.kalango.util;

public class FormatterUtils {

}
