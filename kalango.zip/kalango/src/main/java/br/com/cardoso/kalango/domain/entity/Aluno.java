package br.com.cardoso.kalango.domain.entity;

public class Aluno {

	/* 
	 
	 nome
	 dataNascimento
	 sexo
	 
	 responsaveis
	 	 
	 */
}
