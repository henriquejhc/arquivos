package br.com.cardoso.kalango.util;

public class JsonUtils {

}
