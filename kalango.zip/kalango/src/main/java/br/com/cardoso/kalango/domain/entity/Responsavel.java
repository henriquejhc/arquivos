package br.com.cardoso.kalango.domain.entity;

public class Responsavel {

}
