package br.com.systemglass.toolglass.dto.base;

import java.io.Serializable;

public class GenericFilter<T> implements Serializable {

    private static final long serialVersionUID = 4086406017741977667L;
    
    private T filter;
    private int page;
    private int size;

    public GenericFilter() {
        super();
    }
    
    public GenericFilter(T filter, int page, int size) {
        super();
        this.filter = filter;
        this.page = page;
        this.size = size;
    }

    public GenericFilter<T> page(int page) {
        this.page = page;
        return this;
    }
    
    public GenericFilter<T> size(int size) {
        this.size = size;
        return this;
    }
    
    public GenericFilter<T> filter(T filter) {
        this.filter = filter;
        return this;
    }
    
    public T getFilter() {
        return filter;
    }

    public void setFilter(T filter) {
        this.filter = filter;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

}