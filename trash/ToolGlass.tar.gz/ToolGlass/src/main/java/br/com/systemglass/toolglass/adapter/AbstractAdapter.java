package br.com.systemglass.toolglass.adapter;

import java.util.List;
import java.util.stream.Collectors;

public abstract class AbstractAdapter<E, D> {

	public abstract E toEntity(D dto);

	public abstract D toDTO(E dto);

	public List<E> toListEntity(List<D> dtos) {
		return dtos.stream().map(dto -> {
			return toEntity(dto);
		}).collect(Collectors.toList());
	}
	
	public List<D> toListDTO(List<E> entities) {
		return entities.stream().map(entity -> {
			return toDTO(entity);
		}).collect(Collectors.toList());
	}
}