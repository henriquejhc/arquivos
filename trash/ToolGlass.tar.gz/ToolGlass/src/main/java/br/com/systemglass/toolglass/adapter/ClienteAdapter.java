package br.com.systemglass.toolglass.adapter;

import org.springframework.stereotype.Component;

import br.com.systemglass.toolglass.dto.ClienteDTO;
import br.com.systemglass.toolglass.model.PessoaEntity;

@Component
public class ClienteAdapter extends AbstractAdapter<PessoaEntity, ClienteDTO> {

    @Override
    public PessoaEntity toEntity(ClienteDTO dto) {
        return null;
    }

    @Override
    public ClienteDTO toDTO(PessoaEntity dto) {
        return null;
    }

}