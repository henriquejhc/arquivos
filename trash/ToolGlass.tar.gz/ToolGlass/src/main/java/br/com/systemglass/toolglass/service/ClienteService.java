package br.com.systemglass.toolglass.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import br.com.systemglass.toolglass.adapter.ClienteAdapter;
import br.com.systemglass.toolglass.dto.ClienteDTO;
import br.com.systemglass.toolglass.dto.base.GenericFilter;
import br.com.systemglass.toolglass.dto.base.PagedResponse;
import br.com.systemglass.toolglass.model.PessoaEntity;
import br.com.systemglass.toolglass.repository.ClienteRepository;

@Service
public class ClienteService extends DefaultService {

    @Autowired
    private ClienteRepository clienteRepository;
    
    @Autowired
    private ClienteAdapter clienteAdapter;
    
    @SuppressWarnings("unchecked")
    public PagedResponse<ClienteDTO> getClientes(GenericFilter<?> filtro) {
        
        Pageable pageable = PageRequest.of(filtro.getPage(), filtro.getSize());
        
        Page<PessoaEntity> list = clienteRepository.findAll(pageable);
        
        return (PagedResponse<ClienteDTO>) createPagedResponse(list, clienteAdapter.toListDTO(list.getContent()));
    }
    
}
