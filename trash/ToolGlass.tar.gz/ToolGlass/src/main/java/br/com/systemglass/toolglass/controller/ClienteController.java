package br.com.systemglass.toolglass.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.systemglass.toolglass.dto.ClienteDTO;
import br.com.systemglass.toolglass.dto.base.GenericFilter;
import br.com.systemglass.toolglass.dto.base.PagedResponse;
import br.com.systemglass.toolglass.service.ClienteService;
import br.com.systemglass.toolglass.util.AppConstants;

@RestController
@RequestMapping("/api/clientes")
public class ClienteController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ClienteController.class);
    
    @Autowired
    private ClienteService clienteService;
    
    @GetMapping
    public PagedResponse<ClienteDTO> getClientes(
            @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
            @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        
        LOGGER.info("Executando a consulta de clientes...");
        
        return clienteService.getClientes(new GenericFilter<>().page(page).size(size));
    }
}