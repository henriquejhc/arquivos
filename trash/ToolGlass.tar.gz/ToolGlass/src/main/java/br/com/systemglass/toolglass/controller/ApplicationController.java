package br.com.systemglass.toolglass.controller;

import java.io.Serializable;
import java.time.Instant;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/application")
public class ApplicationController {

	@GetMapping
	public InfoApp inforApp() {
		return new InfoApp("Informações sobre a aplicação.", "ToolGlass", Instant.now());
	}
}

class InfoApp implements Serializable {

	private static final long serialVersionUID = 3374354065064688776L;
	private String appName;
	private String info;
	private Instant date;

	public InfoApp() {
		super();
	}

	public InfoApp(String info, String appName, Instant date) {
		super();
		this.info = info;
		this.appName = appName;
		this.date = date;
	}

	public String getInfo() {
		return info;
	}

	public String getAppName() {
		return appName;
	}

	public Instant getDate() {
		return date;
	}
}