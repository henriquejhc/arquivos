package br.com.systemglass.toolglass.service;

import java.util.Collections;
import java.util.List;

import org.springframework.data.domain.Page;

import br.com.systemglass.toolglass.dto.base.PagedResponse;

public abstract class DefaultService {

    protected PagedResponse<?> createPagedResponse(Page<?> page, List<?> content) {
        
        if (page.getTotalElements() == 0) {
            new PagedResponse<>(Collections.emptyList(), page.getNumber(), page.getSize(), page.getTotalElements(), page.getTotalPages(), page.isLast());
        }
        
        return new PagedResponse<>(content, page.getNumber(), page.getSize(), page.getTotalElements(), page.getTotalPages(), page.isLast());
    }
}