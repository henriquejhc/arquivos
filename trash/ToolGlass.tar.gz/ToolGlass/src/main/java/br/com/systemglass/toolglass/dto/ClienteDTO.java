package br.com.systemglass.toolglass.dto;

import java.io.Serializable;

public class ClienteDTO implements Serializable {

    private static final long serialVersionUID = 8239569494899374998L;

}