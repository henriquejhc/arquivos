package br.com.systemglass.toolglass.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

//@Entity
//@Table(name = "pessoa")
public class PessoaEntity {

//    @Id
    private Long id;
    
}
